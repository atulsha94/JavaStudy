package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserInfoServlet
 */
@WebServlet(urlPatterns = { "/info", "/info2" })
public class UserInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h3 align='center'>");
			pw.print("Hello , " + request.getParameter("f1") + "<br/>");
			pw.print("Addr  " + request.getParameter("f2") + "<br/>");
			pw.print("Prefs , " + request.getParameter("f3") + "<br/>");
			pw.print("<a href='s2_cookies'>Next</a>");
			pw.print("</h3>");
		}
	}

}
