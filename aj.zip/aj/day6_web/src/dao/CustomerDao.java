package dao;

import static dao.DBUtils.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dto.CustomerDTO;

public class CustomerDao {
	private Connection cn;
	private PreparedStatement pst1;

	public CustomerDao() throws Exception {
		cn = getConnection();
		// cust validation
		pst1 = cn
				.prepareStatement("select * from my_customers where email = ? and password = ?");

	}

	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		close();
	}

	// crud --validation
	public CustomerDTO validateCustomer(String em, String pass)
			throws Exception {
		CustomerDTO c = null;
		pst1.setString(1, em);
		pst1.setString(2, pass);
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next())
				c = new CustomerDTO(rst.getInt(1), rst.getString(2), pass, em,rst.getDouble(5), rst.getDate(6), rst.getString(7));
		}
		System.out.println("valid cust " + c);
		return c;
	}

}
