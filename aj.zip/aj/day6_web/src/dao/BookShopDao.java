package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import dto.BookDTO;
import dto.CustomerDTO;
import static dao.DBUtils.*;

public class BookShopDao {
	private Connection cn;
	private PreparedStatement pst2, pst3, pst4;

	public BookShopDao() throws Exception {
		cn = getConnection();
		// categories
		pst2 = cn.prepareStatement("select distinct category from books");
		// books by category
		pst3 = cn
				.prepareStatement("select bookid,title from books where category=?");
		// get cart details
		pst4 = cn
				.prepareStatement("select title,author,price from books where bookid=?");

	}

	public void cleanUp() throws Exception {
		if (pst2 != null)
			pst2.close();
		if (pst3 != null)
			pst3.close();
		if (pst4 != null)
			pst4.close();
		close();
	}

	// get categories
	public ArrayList<String> getCategories() throws Exception {
		ArrayList<String> list = new ArrayList<>();
		try (ResultSet rst = pst2.executeQuery()) {
			while (rst.next())
				list.add(rst.getString(1));
		}
		System.out.println("categories " + list);
		return list;
	}

	// get books by category
	public LinkedHashMap<Integer, String> getBooksByCategory(String category)
			throws Exception {
		// empty LHM
		LinkedHashMap<Integer, String> books = new LinkedHashMap<>();
		pst3.setString(1, category);
		try (ResultSet rst = pst3.executeQuery()) {
			while (rst.next())
				books.put(rst.getInt(1), rst.getString(2));
		}
		System.out.println("reted map of books " + books);
		return books;
	}

	// get cart details
	public ArrayList<BookDTO> getCartDetails(ArrayList<Integer> ids)
			throws Exception {
		ArrayList<BookDTO> l1 = new ArrayList<>();
		for (int i : ids) {
			pst4.setInt(1, i);
			try (ResultSet rst = pst4.executeQuery()) {
				if (rst.next())
					l1.add(new BookDTO(rst.getString(1), rst.getString(2), rst
							.getDouble(3)));
			}
		}
		System.out.println("cart " + l1);
		return l1;
	}

}
