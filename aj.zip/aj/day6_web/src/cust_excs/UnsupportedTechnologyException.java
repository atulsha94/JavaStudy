package cust_excs;

public class UnsupportedTechnologyException extends Exception {
	public UnsupportedTechnologyException(String mesg) {
		super(mesg);
	}

}
