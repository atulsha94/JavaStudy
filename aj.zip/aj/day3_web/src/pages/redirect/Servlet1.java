package pages.redirect;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.UserDTO;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s1_redirect")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
//		response.setContentType("text/html");
	//	try (PrintWriter pw = response.getWriter()) {
//			pw.print("<h3 align='center'>");
			// create user dto from req params
			UserDTO user = new UserDTO(request.getParameter("f1"),
					request.getParameter("f2"), request.getParameter("f3"));
			//get session from WC
			HttpSession hs=request.getSession();
			//save clnt details into session scope
			hs.setAttribute("user_dtls", user);
			//display user dtls 
/*			pw.print("From 1st page User details "+user+"<br/>");
			pw.print("From 1st page sess id "+hs.getId()+"<br/>");
			pw.print("From 1st page session new  "+hs.isNew()+"<br/>");
			pw.flush(); --un comment & chk exc
*/			// use clnt pull II --redirect
			response.sendRedirect("s2_redirect");
	//		pw.print("</h3>");
	//	}

	}
}
