package dao;

import java.sql.*;

public class DBUtils {
	private static Connection connection;

	public static Connection getConnection() throws Exception {
		if (connection == null) {
			Class.forName("oracle.jdbc.OracleDriver");
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "rai", "40561");
		}
		return connection;
	}
	public static void close() throws Exception
	{
		if (connection != null) {
			connection.close();
			connection=null;
		}
	}

}
