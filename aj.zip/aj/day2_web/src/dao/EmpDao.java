package dao;

import java.sql.*;
import java.util.ArrayList;

import dto.EmpDTO;
import static dao.DBUtils.*;

public class EmpDao {
	private Connection cn;
	private PreparedStatement pst1;

	public EmpDao() throws Exception {
		cn = getConnection();
		pst1 = cn.prepareStatement("select * from my_emp where deptid=?");
	}

	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		if (cn != null)
			cn.close();
	}

	public ArrayList<EmpDTO> getDeptInfo(String dept) throws Exception {
		ArrayList<EmpDTO> l1 = new ArrayList<>();
		pst1.setString(1, dept);
		try (ResultSet rst = pst1.executeQuery()) {
			while (rst.next())
				l1.add(new EmpDTO(rst.getInt(1), rst.getString(2), rst
						.getString(3), rst.getDouble(4), dept, rst.getDate(6)));
		}
		System.out.println("dao reted list " + l1);
		return l1;
	}

}
