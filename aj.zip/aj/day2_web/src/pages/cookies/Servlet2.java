package pages.cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserDTO;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s2_cookies")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			pw.print("<h3 align='center'>");
			// get cookies from rq header
			Cookie[] cookies = request.getCookies();
			// chk if null
			if (cookies != null) {
				// display user dtls
				for (Cookie c : cookies)
					if (c.getName().equals("user_dtls")) {
						pw.print("From 2nd page User details " + c.getValue()
								+ "<br/>");
						break;
					}
			} else
				pw.print("Can't remember clnt<br/>");

			// supply next link
			pw.print("<a href='s3_cookies'>Log Out</a>");
			pw.print("</h3>");
		}

	}
}
