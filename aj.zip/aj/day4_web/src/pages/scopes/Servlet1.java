package pages.scopes;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s1_scopes")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// add attributes on varying scopes
			request.setAttribute("attr1", "val1");
			request.getSession().setAttribute("attr2", "val2");
			getServletContext().setAttribute("attr3", "val3");
			// forward -- server pull
			RequestDispatcher rd = 
					request.getRequestDispatcher("s2_scopes");
			if(rd != null)
				rd.forward(request, response);

		}
	}

}
