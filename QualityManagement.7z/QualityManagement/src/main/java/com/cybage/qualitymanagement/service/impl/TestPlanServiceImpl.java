package com.cybage.qualitymanagement.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestPlanService;

@Service
@Transactional
public class TestPlanServiceImpl implements TestPlanService {

	@Autowired
	TestPlanDao testPlanDao;

	public TestPlanServiceImpl() {
	System.out.println("in service impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel) {
	
		return testPlanDao.addTestPlan(testPlanModel);
		
	
	}
	


	
}
