package dto;

public class UserDTO {
	private String name,address,preferences;
	public UserDTO() {
		// TODO Auto-generated constructor stub
	}
	public UserDTO(String name, String address, String preferences) {
		super();
		this.name = name;
		this.address = address;
		this.preferences = preferences;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPreferences() {
		return preferences;
	}
	public void setPreferences(String preferences) {
		this.preferences = preferences;
	}
	@Override
	public String toString() {
		return "UserDTO [name=" + name + ", address=" + address
				+ ", preferences=" + preferences + "]";
	}
	

}
