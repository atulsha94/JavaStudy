package pages.forward;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s3_forward")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("in 3rd page");
			// add attributes on min reqd scope
			request.setAttribute("attr3", "val3");
			// display all possible req scoped attrs
			Enumeration<String> names = request.getAttributeNames();
			while (names.hasMoreElements()) {
				String nm1 = names.nextElement();
				pw.print("nm : " + nm1 + " val " + request.getAttribute(nm1)+"<br/>");
			}
		}
	}

}
