package pages.cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserDTO;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s3_cookies")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			pw.print("<h3 align='center'>");
			// get cookies from rq header
			Cookie[] cookies = request.getCookies();
			// chk if null
			if (cookies != null) {
				// display user dtls
				for (Cookie c : cookies)
					if (c.getName().equals("user_dtls")) {
						pw.print("From 3rd page User details " + c.getValue()
								+ "<br/>");
						//set max age 0
						c.setMaxAge(0);
						response.addCookie(c);
						break;
					}
			} else
				pw.print("Can't remember clnt<br/>");

			
			pw.print("<a href='index.html'>Visit Again</a>");
			pw.print("</h3>");
		}

	}
}
