package pages.cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserDTO;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s1_cookies")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h3 align='center'>");
			// create user dto from req params
			UserDTO user = new UserDTO(request.getParameter("f1"),
					request.getParameter("f2"), request.getParameter("f3"));
			// add user dtls to cookie --to remember clnt till logout
			//create a cookie
			Cookie c1=new Cookie("user_dtls", user.toString());
			//add cookie to resp hdr
			response.addCookie(c1);
			//display user dtls 
			pw.print("From 1st page User details "+user+"<br/>");
			// supply next link
			pw.print("<a href='s2_cookies'>Next</a>");
			pw.print("</h3>");
		}

	}
}
