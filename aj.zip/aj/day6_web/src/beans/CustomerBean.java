package beans;

import dao.CustomerDao;
import dto.CustomerDTO;

public class CustomerBean {
	// properties ---represents clnt
	private String email, pass;
	private CustomerDao dao;
	private CustomerDTO validCust; 

	public CustomerBean() throws Exception {
		System.out.println("in cust bean constr");
		dao = new CustomerDao();
	}

	public String close() throws Exception {
		if (dao != null)
			dao.cleanUp();
		return "";
	}

	// getters n setters
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public CustomerDao getDao() {
		return dao;
	}
	

	public CustomerDTO getValidCust() {
		return validCust;
	}

	// B.L
	public String validateUser() throws Exception{
		String status = "invalid";
		validCust= dao.validateCustomer(email, pass);
		if (validCust != null)
			status = "valid";
		return status;
	}

}
