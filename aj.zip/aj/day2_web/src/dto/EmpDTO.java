package dto;

import java.sql.Date;

public class EmpDTO {
	private int id;
	private String name,address;
	private double salary;
	private String dept;
	private Date joinDate;
	//def constr
	public EmpDTO() {
		// TODO Auto-generated constructor stub
	}
	public EmpDTO(int id, String name, String address, double salary,
			String dept, Date joinDate) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.dept = dept;
		this.joinDate = joinDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	@Override
	public String toString() {
		return "EmpDTO [id=" + id + ", name=" + name + ", address=" + address
				+ ", salary=" + salary + ", dept=" + dept + ", joinDate="
				+ joinDate + "]";
	}
	

}
