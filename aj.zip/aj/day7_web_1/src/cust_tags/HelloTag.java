package cust_tags;

import java.io.IOException;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class HelloTag extends SimpleTagSupport {
	public HelloTag() {
		System.out.println("in constr of "+getClass().getName());
	}
	@Override
	public void doTag() throws JspException,IOException
	{
		System.out.println("in do-tag");
		getJspContext().getOut().write("welocme 2 custom tags...@ "+new Date());
	}

}
