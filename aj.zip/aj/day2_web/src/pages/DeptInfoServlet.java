package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import dto.EmpDTO;

/**
 * Servlet implementation class DeptInfoServlet
 */
@WebServlet("/dept_info")
public class DeptInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmpDao dao;

	public void init() throws ServletException {
		try {
			dao = new EmpDao();
		} catch (Exception e) {
			// ServletException(String mesg,Throwable cause)
			throw new ServletException(
					"err in init of " + getClass().getName(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		if (dao != null)
			try {
				dao.cleanUp();
			} catch (Exception e) {
				// optional
				throw new RuntimeException("err in destroy", e);

			}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			pw.print("<h3 align='center'>");
			String deptId = request.getParameter("dept");
			ArrayList<EmpDTO> emps = dao.getDeptInfo(deptId);
			if (emps.size() > 0) {
				for (EmpDTO e : emps)
					pw.print(e.getId() + " " + e.getName() + " "
							+ e.getSalary() + " " + e.getJoinDate() + "<br/>");
			} else {
				pw.print("Invalid dept id <br/>");
				pw.print("Pls <a href='dept.html'>Retry</a>");
			}
			pw.print("</h3>");
		} catch (Exception e) {
			// ServletException(String mesg,Throwable cause)
			throw new ServletException("err in do-get of "
					+ getClass().getName(), e);
		}

	}

}
