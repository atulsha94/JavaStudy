package dto;

public class UserDTO {
	private String email,password;
	private double regAmount;
	public UserDTO() {
		// TODO Auto-generated constructor stub
	}
	public UserDTO(String email, String password, double regAmount) {
		super();
		this.email = email;
		this.password = password;
		this.regAmount = regAmount;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	@Override
	public String toString() {
		return "UserDTO email=" + email + ", password=" + password
				+ ", regAmount=" + regAmount;
	}
	

}
