package com.cybage.qualitymanagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestPlanService;

@Controller
@RequestMapping(value = "/test")
public class QualityManagementController {
	
	@Autowired
	TestPlanService testPlanService;

	@RequestMapping(value = "/addTestPlan")
	public ModelAndView showRegForm(TestPlanModel testPlan) {
		System.out.println("add");
		return new ModelAndView("addTestPlan");
	}

	@RequestMapping(value = "/addTestPlan", method = RequestMethod.POST)
	public ModelAndView processForm(TestPlanModel testPlanModel, Model map, HttpSession hs) {
	
	
		TestPlanModel validTestPlanModel = testPlanService.addTestPlan(testPlanModel);
		
		if (validTestPlanModel.getTestPlanId()== null) {
			map.addAttribute("mesg", "Reg Invalid , Pls retry");
			ModelAndView mv = new ModelAndView("helloworld");
			return mv;
		}
		ModelAndView mv = new ModelAndView("valid");
		mv.addObject(validTestPlanModel);
		hs.setAttribute("valid_test", validTestPlanModel);
		hs.setAttribute("status", "Reg Successful");
		return mv;
	}
	
/*	@RequestMapping(value="/JsonTest",produces="application/json",method = RequestMethod.GET)
	public  TestPlanModel showTestPlan() {
		//List<TestPlan> testPlans = Arrays.asList(new TestPlan("a","xyz","executing"), new TestPlan("b","def","running"),
			//	new TestPlan("c", "abc","ready"));
		TestPlanModel testObject=new TestPlanModel("a","xyz","executing");
		System.out.println("in show testPlans JSON");
		return testObject;
		
	}*/
}
