package beans;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class TestBean {
	private ArrayList<String> names;
	private LinkedHashMap<Integer, String> map;
	public TestBean() {
		names=new ArrayList<>();
		names.add("one");
		names.add("two");
		names.add("three");
		names.add("four");
		map=new LinkedHashMap<>();
		map.put(1, "IN");
		map.put(2, "US");
		map.put(3, "RU");
	}
	public ArrayList<String> getNames() {
		return names;
	}
	public LinkedHashMap<Integer, String> getMap() {
		return map;
	}
	

}
