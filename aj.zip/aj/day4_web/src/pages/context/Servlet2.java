package pages.context;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */

public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

	public void init() throws ServletException {
		ServletConfig config = getServletConfig();
		System.out.println("in servlet init " + config);
		// how to get init params from servlet config
		// ServletConfig i/f
		// String getInitParameter(String pName)
		System.out.println("in init of " + getClass().getName()
				+ " init param val " + config.getInitParameter("db_drvr"));
		System.out.println("ctx param "
				+ getServletContext().getInitParameter("abc"));
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletConfig config = getServletConfig();
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// how to get init params from servlet config
			// ServletConfig i/f
			// String getInitParameter(String pName)
			pw.print("in do-get of " + getClass().getName()
					+ " init param val " + config.getInitParameter("db_drvr"));
		}

	}

}
