package pages.sess;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.UserDTO;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/s3_sess")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			pw.print("<h3 align='center'>");
	
			//get existing HS from WC
			HttpSession hs=request.getSession();
			//get clnt details from HS
			UserDTO u=(UserDTO)hs.getAttribute("user_dtls");
			if(u != null) {
				pw.print("Hello ,  "+u.getName()+", u have logged out successfully<br/>");
			}
			else
				pw.print("Can't remember clnt<br/>");
			pw.print("From 3rd page sess id "+hs.getId()+"<br/>");
			pw.print("From 3rd page session new  "+hs.isNew()+"<br/>");
			//discard HS
			hs.invalidate();
			pw.print("<a href='index.html'>Visit Again</a>");
			pw.print("</h3>");
		}

	}
}
