package dto;

import java.io.Serializable;
import java.sql.Date;

public class CustomerDTO implements Serializable {
	private int id;
	private String name,password,email;
	private double regAmount;
	private Date regDate;
	private String role;
	public CustomerDTO() {
		// TODO Auto-generated constructor stub
	}
	public CustomerDTO(int id,String name, String password, String email,
			double regAmount, Date regDate, String role) {
		super();
		this.id=id;
		this.name = name;
		this.password = password;
		this.email = email;
		this.regAmount = regAmount;
		this.regDate = regDate;
		this.role = role;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "CustomerDTO [id=" + id + ", name=" + name + ", password="
				+ password + ", email=" + email + ", regAmount=" + regAmount
				+ ", regDate=" + regDate + ", role=" + role + "]";
	}
	

}
